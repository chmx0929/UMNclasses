/*1.*/
SELECT p.pname FROM prof p
	JOIN dept d ON d.dname = p.dname
WHERE d.numphds < 50;

/*2.*/
SELECT s.sname FROM student s
WHERE s.gpa IN (SELECT MIN(gpa) FROM student);

/*3.*/
SELECT e.cno, e.sectno, AVG(s.gpa) AS AVGGPA FROM enroll e 
	JOIN student s ON s.sid = e.sid
WHERE e.dname = 'Computer Sciences'
GROUP BY e.cno,e.sectno;

/*4.*/
select cname, cno, sectno from (
	select c.cname, c.cno, e.sectno, COUNT(e.sid) AS counter from enroll e
		join course c on c.cno = e.cno
	group by c.cname, c.cno, e.sectno)
where counter < 6 ;

/*5.*/
SELECT s.sname, s.sid FROM student s
WHERE s.sid IN (
	SELECT sid
	FROM enroll GROUP BY sid
	HAVING count (sid) = (
		SELECT MAX(ecount) FROM 
		(
			SELECT e.sid, COUNT(*) AS ecount 
			FROM enroll e
			GROUP BY e.sid
		)));

/*6.*/
SELECT DISTINCT m.dname FROM major m
	JOIN student s ON m.sid = s.sid
WHERE s.age < 18 ;

/*7.*/
SELECT s.sname, m.dname FROM student s
	JOIN major m ON m.sid = s.sid
WHERE s.sid IN (
	SELECT sid FROM enroll WHERE cno IN (
		SELECT cno FROM course WHERE cname LIKE 'College Geometry%'));

/*8.*/
SELECT d.dname, d.numphds 
FROM dept d
WHERE NOT EXISTS
(
	SELECT 1 FROM course c
	WHERE c.dname = d.dname 
	AND c.cname LIKE 'College Geometry%'
);

/*9.*/
SELECT sname FROM student WHERE sid IN (
SELECT sid FROM enroll WHERE dname = 'Computer Sciences'
INTERSECT
SELECT sid FROM enroll WHERE dname = 'Mathematics');

/*10.*/
SELECT t1.mmax - t2.mmin AS age_difference FROM 
	(SELECT MAX(s.age) AS mmax FROM student s WHERE s.sid IN (
		SELECT m.sid FROM major m
		WHERE m.dname = 'Computer Sciences')) t1,
	(SELECT MIN(s.age) AS mmin FROM student s WHERE s.sid IN (
		SELECT m.sid FROM major m
		WHERE m.dname = 'Computer Sciences')) t2;

/*11.*/
SELECT m.dname, AVG(s.gpa) AS AVG_GPA FROM major m 
	JOIN student s ON s.sid = m.sid
WHERE dname IN
(SELECT DISTINCT m.dname FROM major m
	JOIN student s ON s.sid = m.sid
WHERE s.gpa < 1.0)
GROUP BY m.dname;

/*12.*/
SELECT s.sid, s.sname, s.gpa FROM student s
      JOIN enroll e ON s.sid = e.sid
WHERE e.dname = 'Civil Engineering'
GROUP BY s.sid, s.sname, s.gpa
HAVING count(DISTINCT cno) = 
(SELECT count(cno) FROM course WHERE dname = 'Civil Engineering');














INSERT INTO  dept (dname, numphds) VALUES ('Chemical Engineering',	32);
INSERT INTO  dept (dname, numphds) VALUES ('Civil Engineering',	88);
INSERT INTO  dept (dname, numphds) VALUES ('Computer Sciences',	47);
INSERT INTO  dept (dname, numphds) VALUES ('Industrial Engineering',	41);
INSERT INTO  dept (dname, numphds) VALUES ('Mathematics',	129);
INSERT INTO  dept (dname, numphds) VALUES ('Sanitary Engineering',	3);

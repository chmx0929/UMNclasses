This package contains a large dataset of one million rows, along with a short SQL script to load all that data into your database. 
You will need to modify the script to point to where you extracted the data file. You have two data files; values10k.dat and values100k.dat

This package also includes two test SQL files, which will run a large number of SELECT commands and then display the total time taken. 
Students are encouraged to create additional tests as well.
